@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "evilhooked\start-evilginx.ps1"
pause
