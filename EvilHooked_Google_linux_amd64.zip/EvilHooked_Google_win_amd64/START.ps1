Set-Location $PSScriptRoot
& .\evilhooked\start-evilginx.ps1
